CrystalOS para CC:Tweaked
=========================

REQUISITOS
- Minecraft Java com CC:Tweaked instalado.
- Computador do ComputerCraft com espaço livre.
- Para instalação online: HTTP habilitado no servidor/mundo e conexão disponível.
- O pacote ZIP é a distribuição offline.

INSTALAÇÃO PELO ZIP
1. Extraia a pasta CrystalOS para a raiz do computador CC:Tweaked.
2. Copie CrystalOS/startup.lua para /startup.lua (ou renomeie o arquivo e coloque na raiz).
3. Reinicie o computador.

INSTALAÇÃO COM O INSTALADOR LUA
O arquivo crystal_installer.lua é um instalador online. Coloque-o na raiz do computador
e execute: crystal_installer
Ele baixa os arquivos do repositório GitHub e cria /startup.lua.

OBSERVAÇÕES
Esta é uma primeira versão funcional de base, não um clone completo do Windows.
O ambiente CC:Tweaked é baseado em terminal; gráficos, janelas e aplicativos são
limitados pelas capacidades do mod. O código ainda precisa ser testado no jogo.
