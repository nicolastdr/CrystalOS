-- CrystalOS - inicializacao para CC:Tweaked
-- Copie a pasta CrystalOS para a raiz do computador e este arquivo para /startup.lua.
os.setComputerLabel("CrystalOS")
shell.run("/CrystalOS/system/kernel.lua")
